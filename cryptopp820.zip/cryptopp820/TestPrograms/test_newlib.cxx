#include <string>
int main(int argc, char* argv[])
{
#ifndef __NEWLIB__
	XXX
#endif
	return 0;
}
